package com.example.vidcall

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class signUpActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up2)
    }
}